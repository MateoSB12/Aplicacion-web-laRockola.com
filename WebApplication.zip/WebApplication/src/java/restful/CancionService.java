package restful;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.CancionModel;
import restful.Conexion;

public class CancionService {

    public ArrayList<CancionModel> getCanciones() {
        ArrayList<CancionModel> lista = new ArrayList<>();
        Conexion conn = new Conexion();
        String sql = "SELECT * FROM cancion";

        try {
            Statement stm = conn.getCon().createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                CancionModel cancion = new CancionModel();
                cancion.setId_cancion(rs.getString("id_can"));
                cancion.setTitulo_cancion(rs.getString("nombre_can"));
                cancion.setDuracion_cancion(rs.getString("duracion_can"));
                cancion.setId_album(rs.getString("id_alb"));
                lista.add(cancion);
            }
        } catch (SQLException e) {
            System.out.println("error: "+e.getMessage());
        }

        return lista;
    }

    public CancionModel getCanciones(int id_cancion) {
        CancionModel cancion = new CancionModel();
        Conexion conex = new Conexion();
        String Sql = "SELECT * FROM cancion where id_can= ?";

        try {

            PreparedStatement pstm = conex.getCon().prepareStatement(Sql);
            pstm.setInt(1, id_cancion);
            ResultSet rs = pstm.executeQuery();
                     
            while (rs.next()) {
                cancion.setId_cancion(rs.getString("id_can"));
                cancion.setTitulo_cancion(rs.getString("nombre_can"));
                cancion.setId_album(rs.getString("id_alb"));
                cancion.setDuracion_cancion(rs.getString("duracion_can"));
            }
            /*while (rs.next()) {

                
            }*/
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return cancion;
    }

    public CancionModel addCancion(CancionModel cancion) {
        Conexion conex = new Conexion();
        String Sql = "insert into cancion (id_can,nombre_can,id_alb,duracion_can)";
        Sql = Sql + "values (?,?,?,?)";

        try {
            PreparedStatement pstm = conex.getCon().prepareStatement(Sql);
            pstm.setString(1, cancion.getId_cancion());
            pstm.setString(2, cancion.getTitulo_cancion());
            pstm.setString(3, cancion.getId_album());
            pstm.setString(4, cancion.getDuracion_cancion());
            pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
        return cancion;
    }

    public CancionModel updateCancion(CancionModel cancion) {
        Conexion conn = new Conexion();
        String sql = "UPDATE cancion SET nombre_can=?,id_alb=?,duracion_can=? WHERE id_can= ?";
        try {
            PreparedStatement pstm = conn.getCon().prepareStatement(sql);
            pstm.setString(1, cancion.getTitulo_cancion());
            pstm.setString(2, cancion.getId_album());
            pstm.setString(4, cancion.getId_cancion());
            pstm.setString(3, cancion.getDuracion_cancion());
            
            pstm.executeUpdate();
        } catch (SQLException excepcion) {
            System.out.println("Ha ocurrido un error al actualizar  " + excepcion.getMessage());
            return null;
        }
        return cancion;
    }

    public String delCancion(int id_cancion) {
        Conexion conn = new Conexion();

        String sql = "DELETE FROM cancion WHERE id_can= ?";
        try {
            PreparedStatement pstm = conn.getCon().prepareStatement(sql);
            pstm.setInt(1, id_cancion);
            pstm.executeUpdate();
        } catch (SQLException excepcion) {
            System.out.println("Ha ocurrido un error al eliminar  " + excepcion.getMessage());
            return "{\"Accion\":\"Error\"}";
        }
        return "{\"Accion\":\"Registro Borrado\"}";
    }
}
