
package restful;
import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CancionModel {
    private String id_cancion;
    private String titulo_cancion;
    private String id_album;
    private String duracion_cancion;

    public CancionModel() {
    }

    public CancionModel(String id_cancion, String titulo_cancion, String id_album, String duracion_cancion) {
        this.id_cancion = id_cancion;
        this.titulo_cancion = titulo_cancion;
        this.id_album = id_album;
        this.duracion_cancion = duracion_cancion;
        
    }

    public String getId_cancion() {
        return id_cancion;
    }

    public void setId_cancion(String id_cancion) {
        this.id_cancion = id_cancion;
    }

    public String getTitulo_cancion() {
        return titulo_cancion;
    }

    public void setTitulo_cancion(String titulo_cancion) {
        this.titulo_cancion = titulo_cancion;
    }

    public String getId_album() {
        return id_album;
    }

    public void setId_album(String id_album) {
        this.id_album = id_album;
    }

    public String getDuracion_cancion() {
        return duracion_cancion;
    }

    public void setDuracion_cancion(String duracion_cancion) {
        this.duracion_cancion = duracion_cancion;
    }    

}
